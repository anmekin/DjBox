__author__ = 'andrey'
#coding:utf-8
from django.forms import forms, CharField, ModelForm

from handlers import upload_to_dropbox
from models import DropObjet

class UploadFileForm(ModelForm):
    class Meta:
        model = DropObjet
        fields=[]
    #title = CharField(max_length=50)
    file = forms.FileField()

    # для каждого юзера своя папка
    # как передать request или хотя бы username
    def save(self, commit=False):
        f = self.cleaned_data['file']
        obj = super(UploadFileForm, self).save(commit=False)
        obj.path = upload_to_dropbox(f)
        obj = super(UploadFileForm, self).save()
        return obj
        # fileModel = new FileModel(path)

