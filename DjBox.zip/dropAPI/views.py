#coding:utf-8
from django.shortcuts import render
from django.shortcuts import render_to_response, render, redirect, get_object_or_404, get_list_or_404
from django.contrib.auth.models import User
from forms import UploadFileForm
from models import DropObjet
from django.conf import settings
import dropbox


def loadToDropBox(request):
    APP_KEY = 'q860zezp5zss55a'
    APP_SECRET = '0ekwbpg9czsu8l9'
    flow = dropbox.client.DropboxOAuth2FlowNoRedirect(APP_KEY, APP_SECRET)
    authorize_url = flow.start()
    code = raw_input("Enter the authorization code here: ").strip() # WTF?
    access_token, user_id = flow.finish(code)
    client = dropbox.client.DropboxClient(access_token)
    f = open('working-draft.txt', 'rb')
    response = client.put_file('/magnum-opus.txt', f)
    print "uploaded:", response
    return render(request, 'index.html')
# Create your views here.

def upload(request):
    form = UploadFileForm(request.POST or None, request.FILES or None)
    if form.is_valid():
#        print request.FILES
        obj = form.save()
        print obj.path
        #handle_uploaded_file(request.FILES['file'])
        return redirect('/')
    else:
        return render(request, "base.html", {"form": form})

def home(request):
    return render(request, 'base.html')

def userfiles(request):
    files = DropObjet.objects.all()
    for file in files:
        print file.path
    return render(request, "userfiles.html", {'files':files})

def show_file(request):   # лучше через GET, но как передать его в url(templates)
    path = request.GET.get('path')
    print path
    file = get_object_or_404(DropObjet, path="/"+path) # в будующем формировка пути с учетом текущего пользователя
    client = dropbox.client.DropboxClient(settings.AUTH_TOKEN)
    out = open("static/tmp/"+file.get_name(), 'wb')
    with client.get_file(file.path) as f:
        out.write(f.read())
    print f
    return redirect('/')