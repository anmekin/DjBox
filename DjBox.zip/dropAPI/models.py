from django.db import models
from django.contrib.auth.models import User

class DropObjet(models.Model):
    #user=models.ForeignKey(User)
    path = models.CharField(max_length=255)

    def get_name(self):
        return self.path.split('/')[-1]
# Create your models here.
